using UnityEngine;

public class AllPanels : MonoBehaviour
{
    public GameObject[] panels;
    
    
}
